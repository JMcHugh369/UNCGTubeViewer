package com.example.backend.enums;

public enum UserType {
    INFLUENCER, VIEWER
}
