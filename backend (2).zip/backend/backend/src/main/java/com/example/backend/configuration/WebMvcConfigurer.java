package com.example.backend.configuration;

public class WebMvcConfigurer {
}
