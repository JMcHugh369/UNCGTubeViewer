package com.example.backend.entity;

public class enums {
}
